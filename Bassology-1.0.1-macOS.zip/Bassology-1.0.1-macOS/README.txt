Bassology 1.0.1
Free audio plugin for macOS: VST3 + Audio Unit. Intel and Apple Silicon.

INSTALLATION
1. Double-click Bassology-Installer.pkg.
2. If macOS says it cannot verify the developer: open System Settings > Privacy & Security, scroll down, click "Open Anyway", then open the installer again.
3. Click Continue and Install. Enter your Mac password when asked.
4. FL Studio: Options > Manage plugins > Find installed plugins.

UNINSTALL
Delete these two files:
/Library/Audio/Plug-Ins/VST3/Bassology.vst3
/Library/Audio/Plug-Ins/Components/Bassology.component

Built with JUCE (juce.com).
